# Figure and Table Scope Register

All numbers below come from the v8 compilation, not hard-coded captions.

| Object | Page | Scope / purpose |
|---|---:|---|
| Figure 1 (`fig:coordinates`) | 3 | Whole taxonomy: 8 coordinates / 27 subitems |
| Table 1 (`tab:coordinates`) | 4 | Complete taxonomy: interpretation contract |
| Figure 2 (`fig:bridge_1`) | 5 | One coordinate: ML-CV-medical meanings and examples |
| Figure 3 (`fig:timeline_task_synthesis`) | 6 | One named subitem: 20 dated landmarks |
| Figure 4 (`fig:timeline_task_translation`) | 7 | One named subitem: 20 dated landmarks |
| Figure 5 (`fig:timeline_task_editing`) | 8 | One named subitem: 20 dated landmarks |
| Figure 6 (`fig:timeline_task_restoration`) | 9 | One named subitem: 20 dated landmarks |
| Figure 7 (`fig:timeline_task_measurement_reconstruction`) | 10 | One named subitem: 20 dated landmarks |
| Figure 8 (`fig:timeline_task_temporal_generation`) | 11 | One named subitem: 20 dated landmarks |
| Figure 9 (`fig:bridge_2`) | 12 | One coordinate: ML-CV-medical meanings and examples |
| Figure 10 (`fig:timeline_conditioning_conditional`) | 13 | One named subitem: 20 dated landmarks |
| Figure 11 (`fig:timeline_conditioning_text_conditioned`) | 14 | One named subitem: 20 dated landmarks |
| Figure 12 (`fig:timeline_conditioning_controllable`) | 15 | One named subitem: 20 dated landmarks |
| Figure 13 (`fig:bridge_3`) | 16 | One coordinate: ML-CV-medical meanings and examples |
| Figure 14 (`fig:timeline_data_regime_few_shot_unspecified`) | 17 | One named subitem: 20 dated landmarks |
| Figure 15 (`fig:timeline_data_regime_zero_shot`) | 18 | One named subitem: 20 dated landmarks |
| Figure 16 (`fig:timeline_data_regime_data_efficient`) | 19 | One named subitem: 20 dated landmarks |
| Figure 17 (`fig:bridge_4`) | 20 | One coordinate: ML-CV-medical meanings and examples |
| Figure 18 (`fig:timeline_task_organization_multi_task`) | 21 | One named subitem: 20 dated landmarks |
| Figure 19 (`fig:timeline_task_organization_multimodal`) | 22 | One named subitem: 20 dated landmarks |
| Figure 20 (`fig:timeline_task_organization_joint_generation`) | 23 | One named subitem: 20 dated landmarks |
| Figure 21 (`fig:bridge_5`) | 24 | One coordinate: ML-CV-medical meanings and examples |
| Figure 22 (`fig:timeline_output_object_image`) | 25 | One named subitem: 20 dated landmarks |
| Figure 23 (`fig:timeline_output_object_texture`) | 26 | One named subitem: 20 dated landmarks |
| Figure 24 (`fig:timeline_output_object_shape`) | 27 | One named subitem: 20 dated landmarks |
| Figure 25 (`fig:bridge_6`) | 28 | One coordinate: ML-CV-medical meanings and examples |
| Figure 26 (`fig:timeline_temporal_structure_four_d`) | 29 | One named subitem: 20 dated landmarks |
| Figure 27 (`fig:timeline_temporal_structure_temporal_interpolation`) | 30 | One named subitem: 20 dated landmarks |
| Figure 28 (`fig:timeline_temporal_structure_action_conditioned`) | 31 | One named subitem: 20 dated landmarks |
| Figure 29 (`fig:bridge_7`) | 32 | One coordinate: ML-CV-medical meanings and examples |
| Figure 30 (`fig:timeline_model_mechanism_gan`) | 33 | One named subitem: 20 dated landmarks |
| Figure 31 (`fig:timeline_model_mechanism_diffusion`) | 34 | One named subitem: 20 dated landmarks |
| Figure 32 (`fig:timeline_model_mechanism_flow_matching`) | 35 | One named subitem: 20 dated landmarks |
| Figure 33 (`fig:bridge_8`) | 36 | One coordinate: ML-CV-medical meanings and examples |
| Figure 34 (`fig:timeline_requirements_fidelity`) | 37 | One named subitem: 20 dated landmarks |
| Figure 35 (`fig:timeline_requirements_efficiency`) | 38 | One named subitem: 20 dated landmarks |
| Figure 36 (`fig:timeline_requirements_data_consistency`) | 39 | One named subitem: 20 dated landmarks |
| Table 2 (`tab:compositions`) | 40 | Five selected cross-coordinate lexical pairs |
| Table 3 (`tab:evidence`) | 41 | Named medical studies; not a field maturity score |
| Figure 37 (`fig:medical_paths`) | 42 | Selected medical workflow validation |
| Figure 38 (`fig:research_gates`) | 44 | General research-selection workflow |
| Table 4 (`tab:agenda`) | 45 | Four medical-oriented opportunity tests |
