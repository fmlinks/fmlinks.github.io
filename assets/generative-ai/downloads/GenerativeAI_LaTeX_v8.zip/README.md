# GenerativeAI v8: Compact Timelines

Main file: `main.tex`. All required figure PDFs, bibliography, template and final `main.bbl` are included. Use Tectonic or `pdflatex`, `bibtex`, then two further `pdflatex` passes. The scientific text, captions, references and 11 non-timeline figures are unchanged from v7.

This revision redraws all 27 publication histories with shorter vertical stems and smaller title/footer bands. It does not squash raster images or reduce font size: source Arial20/24, 14-inch width and final printed text size remain unchanged. Near/far distances are 0.30/1.22 source inches; the order remains -1,+1,-2,+2. Every original paper, date, label, reference number, x position and nonuniform year position is retained. Each figure is about27% shorter.

All figures and tables remain with related prose. The keep-with-text reservations are reduced to fit the shorter graphics; no dedicated figure pages or landscape pages are added. Actual page counts and context checks are in `delivery_validation.json`, with current numbers/pages in `FIGURE_TABLE_REGISTER.md`.

## Reproduce the 27 Redrawn Figures

From the ZIP's `repro` directory, with Python, Matplotlib, NumPy, pandas and Pillow installed:

```powershell
python -X utf8 scripts/render_compact_timelines_v8.py
```

The catalogue, frozen citation numbers and v7 geometry baseline are included. Output PDF/SVG/PNG files are under `figures/compact_v8/timelines`; the renderer also writes PDFs under its project-shaped `manuscript/compact_v8/figures/timelines`. Copy the generated PDFs to the root paper's matching figure folder before recompiling. The v5-named helper provides verified label wrapping and collision/export checks, not old scientific content.

After changing bibliography order, first compile, put the resulting `main.aux` in `repro/manuscript/compact_v8/build/main.aux`, rerender and replace the timeline PDFs, then compile again. Otherwise embedded reference numbers can become stale.

This narrow layout-reproduction package does not rerun or alter literature retrieval or corpus statistics. The complete frozen statistical-data reproduction remains in the preserved v7 delivery. All v8 source PDFs and tables needed to compile this paper are self-contained here.
