"""Shorter vertical geometry; preserve every v7 paper, label and x coordinate."""
import json
from pathlib import Path
import re

import pandas as pd

import render_subtask_timelines_v5 as base
from package_review_delivery import copy

ROOT = Path(__file__).resolve().parents[1]
R = ROOT / "research/compact_timelines_v8"
P = ROOT / "manuscript/compact_v8"
OUT = ROOT / "figures/compact_v8/timelines"
NEAR = .30
FAR = 1.22
HEADER = .50
FOOTER = .48
LABEL_ARROW_GAP = .10


def layout(task, papers, references):
    panel = base.layout(task, papers, references)
    for node in panel["nodes"]:
        node["distance"] = NEAR if abs(node["level"]) == 1 else FAR
        node["arrow_end"] = node["side"] * (node["distance"] - LABEL_ARROW_GAP)
    upper = max(n["distance"] + n["height"] for n in panel["nodes"] if n["side"] > 0)
    lower = max(n["distance"] + n["height"] for n in panel["nodes"] if n["side"] < 0)
    panel.update({"height": upper + lower + HEADER + FOOTER, "axis_y": lower + FOOTER,
                  "upper": upper, "lower": lower, "header_inches": HEADER, "footer_inches": FOOTER})
    return panel


def draw(ax, task, panel, number, offset=0):
    axis = offset + panel["axis_y"]
    ax.text(.22, offset + panel["height"] - .20, f"{number:02}  {task['name']}", fontsize=24,
            weight="bold", va="center", color="black")
    ax.annotate("", xy=(13.3, axis), xytext=(.65, axis),
                arrowprops={"arrowstyle": "-|>", "color": "black", "lw": 1.25, "mutation_scale": 18})
    for year in panel["year_labels"]:
        ax.text(year["x"], offset + .18, year["text"], fontsize=20, ha="center", va="center", color="black")
    stems = []
    for n in panel["nodes"]:
        end = axis + n["arrow_end"]
        ax.annotate("", xy=(n["x"], end), xytext=(n["x"], axis),
                    arrowprops={"arrowstyle": "-|>", "color": "black", "lw": 1.25, "mutation_scale": 16, "shrinkA": 0, "shrinkB": 0})
        ax.text(n["x"], axis + n["side"] * n["distance"], n["text"], fontsize=20,
                ha="center", va="bottom" if n["side"] > 0 else "top", linespacing=1.04, color="black")
        stems.append((n["x"], axis, end, n["text"]))
    return stems


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    catalog = json.loads((R / "timeline_catalog.json").read_text(encoding="utf-8"))
    aux = P / "build/main.aux"
    refs = ({k: int(v) for k, v in re.findall(r"\\bibcite\{([^}]+)\}\{\{(\d+)\}", aux.read_text(encoding="utf-8"))}
            if aux.exists() else json.loads((R / "citation_numbers.json").read_text()))
    assert set(catalog["papers"]) <= set(refs)
    (R / "citation_numbers.json").write_text(json.dumps(refs, indent=2), encoding="utf-8")
    old = json.loads((R / "v7_geometry_baseline.json").read_text())
    reports, geometry = [], {}
    index = 0
    for gi, group in enumerate(catalog["facets"], 1):
        for label in group["leaves"]:
            index += 1
            task = catalog["subtasks"][label]
            panel = layout(task, catalog["papers"], refs)
            stem = f"T{index:02}_" + label.split(":")[1]
            fig, ax = base.make_canvas(panel["height"])
            stems = draw(ax, task, panel, index)
            report = base.export(fig, OUT / stem, stems)
            report.update({"old_height_inches": old["geometry"][label]["height"],
                           "height_reduction_percent": 100 * (1 - panel["height"] / old["geometry"][label]["height"]),
                           "minimum_print_font_at_6_5in": 20 * 6.5 / base.WIDTH})
            reports.append(report)
            geometry[label] = {**panel, "file": stem, "group": gi, "index": index}
            copy(OUT / (stem + ".pdf"), P / "figures/timelines" / (stem + ".pdf"))
    checks = {"27_timelines": index == 27, "all_layouts_pass": all(f["status"] == "passed" for f in reports),
              "all_at_least_25_percent_shorter": all(f["height_reduction_percent"] >= 25 for f in reports),
              "540_original_papers_labels_x_and_levels_unchanged": all(
                  [(n["key"], n["text"], n["x"], n["level"]) for n in panel["nodes"]] ==
                  [(n["key"], n["text"], n["x"], n["level"]) for n in old["geometry"][label]["nodes"]]
                  for label, panel in geometry.items()),
              "year_positions_unchanged": all(p["year_labels"] == old["geometry"][k]["year_labels"] for k, p in geometry.items())}
    report = {"status": "passed" if all(checks.values()) else "needs_repair", "checks": checks, "geometry": geometry,
              "figures": reports, "reference_numbers": refs, "source_font_sizes": [20, 24],
              "layout": {"near": NEAR, "far": FAR, "header": HEADER, "footer": FOOTER, "title_center_from_top": .20},
              "scientific_content": "Unchanged; vertical layout only"}
    (OUT / "timeline_figure_validation.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    pd.DataFrame([{"subtask": k, "index": p["index"], "old_height_in": old["geometry"][k]["height"],
                   "new_height_in": p["height"], "reduction_percent": 100 * (1 - p["height"] / old["geometry"][k]["height"])}
                  for k, p in geometry.items()]).to_csv(R / "height_comparison.csv", index=False, encoding="utf-8-sig")
    print(json.dumps({"status": report["status"], "checks": checks, "repairs": [f for f in reports if f["status"] != "passed"],
                      "height_range": [min(p["height"] for p in geometry.values()), max(p["height"] for p in geometry.values())]}, indent=2))
    assert report["status"] == "passed"


if __name__ == "__main__":
    main()
