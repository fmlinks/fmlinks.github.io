"""Equal-paper-spaced, citation-linked arrow timelines in eight groups."""
import json
from pathlib import Path
import re
import textwrap

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.text import Text
import numpy as np
import pandas as pd
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
R = ROOT / "research/timeline_revision_v5"
OUT = ROOT / "figures/compact_v5/timelines"
WIDTH = 14
plt.rcParams.update({"font.family": "Arial", "font.size": 20, "svg.fonttype": "none", "pdf.fonttype": 42})


def measured(value):
    f = plt.figure(figsize=(WIDTH, 3))
    t = f.text(0, 0, value, fontsize=20, linespacing=1.04)
    f.canvas.draw()
    box = t.get_window_extent(f.canvas.get_renderer())
    result = box.width/f.dpi, box.height/f.dpi
    plt.close(f)
    return result


def layout(task, papers, references):
    nodes = []
    for i, key in enumerate(task["paper_keys"]):
        p = papers[key]
        name=p["short_name"]
        label = name + f"\n[{references[key]}]"
        w, h = measured(label)
        limit=2.70 if i%4 in [2,3] else 2.18
        if w>limit:
            name=re.sub(r"(?<=[a-z0-9])(?=[A-Z][a-z])"," ",p["short_name"])
            label=textwrap.fill(name,14,break_long_words=True,break_on_hyphens=True)+f"\n[{references[key]}]"
            w,h=measured(label)
        level=[-1,1,-2,2][i%4]
        side=1 if level>0 else -1
        distance=.55 if abs(level)==1 else 1.65
        x=1.4+i*11.2/19
        nodes.append({"key": key, "date": p["date"], "x":x, "text": label, "width": w, "height": h, "side":side,
                      "level":level,"distance":distance,"x_bounds":[x-w/2,x+w/2],"arrow_end":side*(distance-.12)})
    # Both requested invariants are fixed: equal x gaps and -1,+1,-2,+2 heights.
    upper = max(n["distance"]+n["height"] for n in nodes if n["side"]>0)
    lower = max(n["distance"]+n["height"] for n in nodes if n["side"]<0)
    years={y:float(np.mean([n["x"] for n in nodes if int(n["date"][:4])==y])) for y in range(2018,2027) if any(int(n["date"][:4])==y for n in nodes)}
    years.setdefault(2018,.65)
    years.setdefault(2026,13.35)
    year_labels=[]
    for year,x in sorted(years.items()):
        text=str(year)+("*" if year==2026 else "")
        w,h=measured(text)
        if year_labels:
            previous=year_labels[-1]
            x=max(x,previous["x"]+(previous["width"]+w)/2+.10)
        year_labels.append({"year":year,"text":text,"x":x,"row":0,"width":w})
    footer=.75+.35*max(y["row"] for y in year_labels)
    return {"nodes": nodes, "height": upper+lower+footer+1.05, "axis_y": lower+footer, "upper": upper, "lower": lower,"year_labels":year_labels,"paper_spacing_inches":11.2/19,"axis_semantics":"ordinal paper chronology, nonuniform year positions"}


def draw_panel(ax, task, panel, color, number, offset=0):
    color="black"
    axis = offset + panel["axis_y"]
    title = f"{number:02}  {task['name']}"
    ax.text(.22, offset+panel["height"]-.32, title, fontsize=24, weight="bold", va="center", color=color)
    ax.annotate("", xy=(13.3,axis), xytext=(.65,axis), arrowprops={"arrowstyle":"-|>","color":"black","lw":1.25,"mutation_scale":18})
    for y in panel["year_labels"]:
        ax.text(y["x"],offset+.26+.35*y["row"],y["text"],fontsize=20,ha="center",va="center")
    stems = []
    for n in panel["nodes"]:
        end = axis+n["arrow_end"]
        ax.annotate("", xy=(n["x"],end), xytext=(n["x"],axis), arrowprops={"arrowstyle":"-|>","color":color,"lw":1.25,"mutation_scale":16,"shrinkA":0,"shrinkB":0})
        ax.text(n["x"],axis+n["side"]*n["distance"],n["text"],fontsize=20,ha="center",va="bottom" if n["side"]>0 else "top",linespacing=1.04,color=color)
        stems.append((n["x"],axis,end,n["text"]))
    return stems


def export(fig, path, stems, *, dpi=250):
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    items = [(t,t.get_window_extent(renderer)) for t in fig.findobj(Text) if t.get_visible() and t.get_text()]
    overlaps = [[a.get_text(),b.get_text()] for i,(a,ba) in enumerate(items) for b,bb in items[i+1:] if ba.overlaps(bb)]
    outside = [t.get_text() for t,b in items if b.x0<-.1 or b.y0<-.1 or b.x1>fig.bbox.width+.1 or b.y1>fig.bbox.height+.1]
    crossings = []
    ax = fig.axes[0]
    for x,a,b,own in stems:
        pa,pb = ax.transData.transform([(x,a),(x,b)])
        for t,box in items:
            if t.get_text() == own:
                continue
            if box.x0<pa[0]<box.x1 and box.y0<max(pa[1],pb[1]) and box.y1>min(pa[1],pb[1]):
                crossings.append([own,t.get_text()])
    path.parent.mkdir(parents=True,exist_ok=True)
    for ext in ["pdf","svg","png"]:
        fig.savefig(path.with_suffix("."+ext),dpi=dpi,facecolor="white")
    sizes = sorted({t.get_fontsize() for t,_ in items})
    fraction = float(np.any(np.asarray(Image.open(path.with_suffix(".png")).convert("RGB"))<240,axis=2).mean())
    monochrome=all(str(t.get_color()) in {"black","#000000"} for t,_ in items)
    report = {"name":path.stem,"font_sizes":sizes,"font_family":"Arial","size_inches":fig.get_size_inches().tolist(),"text_overlaps":overlaps,"text_outside":outside,"stem_text_crossings":crossings,"nonwhite_pixel_fraction":fraction,"all_text_black":monochrome}
    report["status"] = "passed" if not overlaps and not outside and not crossings and set(sizes)<={20,24} and fraction>.005 and monochrome else "needs_repair"
    plt.close(fig)
    return report


def make_canvas(height):
    fig,ax=plt.subplots(figsize=(WIDTH,height))
    fig.subplots_adjust(left=0,right=1,bottom=0,top=1)
    ax.set(xlim=(0,WIDTH),ylim=(0,height))
    ax.axis("off")
    return fig,ax


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    catalog=json.loads((R/"timeline_catalog.json").read_text(encoding="utf-8"))
    aux_path=ROOT/"manuscript/compact_v5/build/main.aux"
    if aux_path.exists():
        aux=aux_path.read_text(encoding="utf-8")
        refs={k:int(v) for k,v in re.findall(r"\\bibcite\{([^}]+)\}\{\{(\d+)\}",aux)}
        (R/"citation_numbers.json").write_text(json.dumps(refs,indent=2),encoding="utf-8")
    else:
        refs=json.loads((R/"citation_numbers.json").read_text(encoding="utf-8"))
    missing=set(catalog["papers"])-set(refs)
    if missing:
        raise ValueError(f"Compile all timeline citations first: {sorted(missing)[:15]}")
    reports,geometries=[],{}
    counter=0
    for gi,group in enumerate(catalog["facets"],1):
        layouts=[]
        for label in group["leaves"]:
            counter+=1
            task=catalog["subtasks"][label]
            panel=layout(task,catalog["papers"],refs)
            stem=f"T{counter:02}_{label.split(':')[1]}"
            fig,ax=make_canvas(panel["height"])
            stems=draw_panel(ax,task,panel,group["color"],counter)
            reports.append(export(fig,OUT/stem,stems))
            geometries[label]={**panel,"file":stem,"group":gi,"index":counter,"source_width_in":WIDTH,"minimum_print_font_at_6_5in":20*6.5/WIDTH}
            layouts.append((label,panel,counter))
        height=sum(p["height"] for _,p,_ in layouts)+.8
        fig,ax=make_canvas(height)
        ax.text(.22,height-.3,group["name"].replace("\n"," ")+" | 2018-2026*",fontsize=24,weight="bold",va="center",color="black")
        offset=height-.8
        stems=[]
        for label,panel,index in layouts:
            offset-=panel["height"]
            stems+=draw_panel(ax,catalog["subtasks"][label],panel,group["color"],index,offset)
        reports.append(export(fig,OUT/f"G{gi:02}_composite",stems,dpi=120))
    checks={"27_timelines":counter==27,"540_nodes":sum(len(p["nodes"]) for p in geometries.values())==540,"all_layouts_pass":all(r["status"]=="passed" for r in reports),"equal_paper_spacing":all(np.allclose(np.diff([n['x'] for n in p['nodes']]),11.2/19,rtol=0,atol=1e-12) for p in geometries.values()),"two_layers_each_side":all([n['level'] for n in p['nodes']]==[-1,1,-2,2]*5 for p in geometries.values()),"chronological_order":all([n['date'] for n in p['nodes']]==sorted(n['date'] for n in p['nodes']) for p in geometries.values()),"20_24_source_fonts":all(set(r["font_sizes"])<={20,24} for r in reports)}
    report={"status":"passed" if all(checks.values()) else "needs_repair","checks":checks,"figures":reports,"geometry":geometries,"reference_numbers":refs,"year_window":[2018,2026],"date_basis":"First arXiv date except explicitly logged source-release bases; paper nodes evenly spaced in date order, year positions nonuniform","arrow_style":"All-black vertical arrows, paper labels, citations, titles and horizontal time axes","ytd_cutoff":"2026-10-22"}
    (OUT/"timeline_figure_validation.json").write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
    pd.DataFrame([{"label":label,"node":i+1,"bibkey":n["key"],"reference":refs[n["key"]],"date":n["date"],"x_inches":n["x"],"level":n["level"]} for label,p in geometries.items() for i,n in enumerate(p["nodes"])]).to_csv(R/"timeline_node_positions.csv",index=False,encoding="utf-8-sig")
    print(json.dumps({"status":report["status"],"checks":checks,"repairs":[r for r in reports if r["status"]!="passed"]},indent=2))
    if report["status"]!="passed":
        raise SystemExit(1)


if __name__=="__main__":
    main()
