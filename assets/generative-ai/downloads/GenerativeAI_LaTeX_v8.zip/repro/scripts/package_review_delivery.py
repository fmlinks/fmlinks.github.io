"""Package a reproducible source snapshot and validate a clean extracted compile."""
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import zipfile

import fitz
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
R = ROOT / "research/review_v1"
P = ROOT / "manuscript/compact_v1"
S = ROOT / "submit/GenerativeAI_compact_v1"
TECTONIC = Path(r"C:\Program Files\WindowsApps\OpenAI.Codex_26.1016.6573.0_x64__2p2nqsd0c76g0\app\resources\tectonic\tectonic.exe")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def copy(a, b):
    b.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(a, b)


def compile_pdf(project):
    (project / "build").mkdir(exist_ok=True)
    result = subprocess.run([str(TECTONIC), "-X", "compile", "--outdir", "build", "--keep-logs", "--keep-intermediates", "main.tex"], cwd=project, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=180)
    (project / "build/compiler_console.txt").write_text(result.stdout + result.stderr, encoding="utf-8")
    if result.returncode:
        raise RuntimeError(result.stdout + result.stderr)


def main():
    S.mkdir(parents=True, exist_ok=True)
    for source in (ROOT / "figures/compact_v1").glob("*.pdf"):
        copy(source, P / "figures" / source.name)
    copy(R / "references.bib", P / "references.bib")
    compile_pdf(P)
    pdf = fitz.open(P / "build/main.pdf")
    content = "\n".join(page.get_text() for page in pdf)
    files = [P / "main.tex"] + sorted((P / "sections").glob("*.tex")) + sorted((P / "tables").glob("*.tex"))
    sections = "\n".join(f.read_text(encoding="utf-8") for f in sorted((P / "sections").glob("*.tex")))
    tex = "\n".join(f.read_text(encoding="utf-8") for f in files)
    cites = set(k.strip() for group in re.findall(r"\\cite\w*\{([^}]+)\}", tex) for k in group.split(","))
    bibkeys = set(re.findall(r"@\w+\{([^,]+),", (P / "references.bib").read_text(encoding="utf-8")))
    labels = re.findall(r"\\label\{([^}]+)\}", tex)
    refs = re.findall(r"\\(?:ref|eqref)\{([^}]+)\}", tex)
    log = (P / "build/main.log").read_text(encoding="utf-8", errors="replace")
    paragraphs = []
    for file in sorted((P / "sections").glob("*.tex")):
        chunks = re.split(r"\\para\{(P\d+)\}\s*", file.read_text(encoding="utf-8"))
        for i in range(1, len(chunks), 2):
            passage = re.split(r"\\(?:begin\{figure\}|input\{|subsection\{|section\{)", chunks[i+1])[0]
            keys = sorted(set(k.strip() for g in re.findall(r"\\cite\w*\{([^}]+)\}", passage) for k in g.split(",")))
            paragraphs.append({"paragraph": chunks[i], "source": file.relative_to(ROOT).as_posix(), "citation_keys": ";".join(keys), "evidence_type": "source_synthesis" if keys else "review_method_or_interpretation", "text": passage.strip()})
    pd.DataFrame(paragraphs).to_csv(R / "paragraph_evidence.csv", index=False, encoding="utf-8-sig")
    # Machine checks detect geometric overflow, not whether clinical interpretations are correct.
    outside = []
    page_receipts = []
    qa = R / "qa"
    qa.mkdir(exist_ok=True)
    for i, page in enumerate(pdf):
        for block in page.get_text("dict")["blocks"]:
            for line in block.get("lines", []):
                for span in line["spans"]:
                    x0, y0, x1, y1 = span["bbox"]
                    if span["text"].strip() and (x0 < 0 or y0 < 0 or x1 > page.rect.width or y1 > page.rect.height):
                        outside.append([i+1, span["text"]])
        pix = page.get_pixmap(matrix=fitz.Matrix(1, 1))
        pix.save(qa / f"page_{i+1:02}.png")
        page_receipts.append({"page": i+1, "characters": len(page.get_text()), "raster": f"qa/page_{i+1:02}.png"})
    figures = json.loads((ROOT / "figures/compact_v1/figure_validation.json").read_text())
    timeline = json.loads((ROOT / "figures/compact_v1/F2_timeline_validation.json").read_text())
    text_nofigs = re.sub(r"\\begin\{figure\}.*?\\end\{figure\}", "", sections, flags=re.S)
    words = len(re.findall(r"\b[A-Za-z]+(?:[-'][A-Za-z]+)*\b", re.sub(r"\\[a-zA-Z]+\{[^{}]*\}", " ", text_nofigs)))
    checks = {"minimum_15_pages": len(pdf) >= 15, "eight_sections": len(re.findall(r"\\section\{", sections)) == 8, "42_paragraph_ids": [r["paragraph"] for r in paragraphs] == [f"P{i:02}" for i in range(1, 43)], "six_figures": tex.count(r"\begin{figure}") == 6, "four_tables": tex.count(r"\begin{table}") == 4, "citations_resolved": not (cites-bibkeys), "labels_resolved": set(refs) <= set(labels) and len(labels) == len(set(labels)), "no_placeholders": not re.search(r"TODO|TBD|FIXME|\[\?\]", content+tex), "no_undefined_tex": not re.search(r"undefined|Overfull", log, re.I), "no_offpage_text": not outside, "nonblank_pages": all(p["characters"] > 300 for p in page_receipts), "figure_checks": all(x["status"] == "passed" for x in figures) and timeline["status"] == "passed", "60_source_families": len(pd.read_csv(R / "qualitative_evidence.csv")) == 60}
    if not all(checks.values()):
        raise AssertionError(checks)
    report = {"status": "passed_pending_clean_extract", "python": sys.executable, "compiler": str(TECTONIC), "pdf_pages": len(pdf), "body_words_approx_excluding_tables_figures_references": words, "actual_references_cited": len(cites), "checks": checks, "offpage_text": outside, "page_receipts": page_receipts, "scientific_validation": "Single AI-assisted extraction; no independent human/clinical adjudication, model experiment or novelty proof", "remaining_tex_warnings": sorted(set(re.findall(r"(?:Underfull[^\n]+)", log))), "reviewer_render_check": "Human-scale rendered pages inspected by Codex; source figure bboxes checked. Not independent expert review."}
    # Build an isolated archive stage without generated TeX intermediates or copyrighted articles.
    stage = S / "source"
    stage.mkdir(exist_ok=True)
    for f in [P / "main.tex", P / "references.bib", P / "PRIMEarxiv.sty", P / "README.md"] + list((P / "sections").glob("*.tex")) + list((P / "tables").glob("*.tex")) + list((P / "figures").glob("*.pdf")):
        copy(f, stage / f.relative_to(P))
    copy(P / "build/main.bbl", stage / "main.bbl")
    for f in list(R.glob("*.json")) + list(R.glob("*.csv")) + [R / "PROTOCOL.md", R / "DEEP_ANALYSIS_ZH.md", R / "DEEP_ANALYSIS_ZH.html"] + list((R / "analysis").glob("*")):
        if f.is_file():
            copy(f, stage / "repro" / f.relative_to(ROOT))
    for name in ["collect_metadata.py", "coding_rules.py", "finalize_review_analysis.py", "render_review_figures.py", "render_timeline_preview.py"]:
        copy(ROOT / "scripts" / name, stage / "repro/scripts" / name)
    copy(ROOT / "design/compact_v1/timeline_anchors.json", stage / "repro/design/compact_v1/timeline_anchors.json")
    for f in (ROOT / "figures/compact_v1").glob("*"):
        if f.is_file():
            copy(f, stage / "repro/figures/compact_v1" / f.name)
    (stage / "repro/requirements.txt").write_text("pandas\nnumpy\nmatplotlib\nPillow\nrequests\nbeautifulsoup4\n", encoding="utf-8")
    report_path = R / "delivery_validation.json"
    report_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
    copy(report_path, stage / "repro/research/review_v1/delivery_validation.json")
    archive = S / "GenerativeAI_LaTeX_v1.zip"
    def make_zip():
        with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as z:
            for f in sorted(stage.rglob("*")):
                if f.is_file():
                    z.write(f, f.relative_to(stage))
    make_zip()
    clean = S / "clean_extract_check"
    clean.mkdir(exist_ok=True)
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        z.extractall(clean)
    compile_pdf(clean)
    rebuilt = fitz.open(clean / "build/main.pdf")
    report["checks"]["clean_extract_recompiled"] = len(rebuilt) == len(pdf) and [p.get_text() for p in rebuilt] == [p.get_text() for p in pdf]
    report["checks"]["template_style_unchanged"] = sha(P / "PRIMEarxiv.sty") == hashlib.sha256(zipfile.ZipFile(ROOT.parent / "template/Arxiv_Latex_Template.zip").read("PRIMEarxiv.sty")).hexdigest()
    for script in ["finalize_review_analysis.py", "render_review_figures.py"]:
        run = subprocess.run([sys.executable, "-X", "utf8", "scripts/" + script], cwd=clean / "repro", capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=120)
        (clean / "build" / (script + ".log")).write_text(run.stdout + run.stderr, encoding="utf-8")
        if run.returncode:
            raise RuntimeError(script + " failed in extracted archive: " + run.stderr)
    report["checks"]["clean_extract_statistics_reproduced"] = all(sha(R / "analysis" / name) == sha(clean / "repro/research/review_v1/analysis" / name) for name in ["robust_trends.csv", "trend_sensitivity.csv", "audit_adjudicated.csv"])
    report["checks"]["clean_extract_six_figure_pixels_reproduced"] = all(sha(f) == sha(clean / "repro/figures/compact_v1" / f.name) for f in (ROOT / "figures/compact_v1").glob("*.png"))
    report["status"] = "passed" if all(report["checks"].values()) else "failed"
    report["pdf_sha256"] = sha(P / "build/main.pdf")
    report["clean_extract_pdf_sha256"] = sha(clean / "build/main.pdf")
    report_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
    copy(report_path, stage / "repro/research/review_v1/delivery_validation.json")
    make_zip()
    copy(P / "build/main.pdf", S / "GenerativeAI_survey_v1.pdf")
    copy(report_path, S / "delivery_validation.json")
    copy(R / "DEEP_ANALYSIS_ZH.html", S / "DEEP_ANALYSIS_ZH.html")
    copy(R / "DEEP_ANALYSIS_ZH.md", S / "DEEP_ANALYSIS_ZH.md")
    manifest = {f.name: {"bytes": f.stat().st_size, "sha256": sha(f)} for f in [archive, S / "GenerativeAI_survey_v1.pdf", S / "delivery_validation.json"]}
    (S / "artifact_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(json.dumps({"status": report["status"], "pages": len(pdf), "references": len(cites), "approx_body_words": words, "checks": report["checks"], "artifacts": manifest}, indent=2))
    if report["status"] != "passed":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
