# Generative AI Survey

Open `main.tex` and compile with the included PRIMEarxiv style and bibliography.

Authors: Fengming Lin and Fangjun Li.

School of Computer Science, University of Manchester.

Project Page: https://fmlinks.github.io/library/generative-ai/

This reading revision retains the taxonomy, statistical frame, source-linked histories and general evidence discussion.
